class Tutor extends Teacher{
    private double Salary;
    private String AppointedDate;
    private String evaluationPeriod;
    private String terminationDate;
    private String qualification;
    private String appointedBy;
    private boolean joined;
    public Tutor(String Subject,String interviewerName,int classesPerday,double Salary,String AppointedBy,String terminationDate){
        super(Subject,interviewerName,classesPerday);
        this.Salary = Salary;
        this.appointedBy = AppointedBy;
        this.terminationDate = terminationDate;
        AppointedDate = "";
        evaluationPeriod = "";
        qualification = "";
        joined = false;
    }
    public String getappointedBy(){
        return this.appointedBy;
    }
    public String getAppointedDate(){
        return this.AppointedDate;
    }
    public String getqualification(){
        return this.qualification;
    } 
    public String getevaluationPeriod(){
        return this.evaluationPeriod;
    }
    public String getterminationDate(){
        return this.terminationDate;
    }
    public boolean getjoined(){
        return this.joined;
    }
    public double getSalary(){
        return this.Salary;
    }
    public void setAppointedDate(String AppointedDate){
        this.AppointedDate = AppointedDate;
    }
    public void setevaluationPeriod(String evaluationPeriod){
        this.evaluationPeriod = evaluationPeriod;
    }
    public void setqualification(String qualification){
        this.qualification = qualification;
    }
    public void setSalary(double Salary){
        if (this.joined == false){
            this.Salary = Salary;
        }
        else{
            System.out.println("The salary cannot be changed because the Lecturor is already appointed");
        }
    }
    public void AppointTutor(String TutorName,String AppointedDate,String terminationDate,String evaluationPeriod,String qualification){
        if (joined == false){
            setteacherName(TutorName);
            this.AppointedDate = AppointedDate;
            this.terminationDate = terminationDate;
            this.qualification = qualification;
            this.evaluationPeriod = evaluationPeriod;
            joined = true;
            
        }
        else{
            System.out.println("The Tutor is already appointed");
            System.out.println("Tutor was appointed at :"+getAppointedDate());
        }
    }
    public void display(){
        super.display();
        if(joined == true){
            System.out.println("The tutor was appointed by "+ appointedBy);
            System.out.println("The appointed date of tutor is "+AppointedDate);
            System.out.println("The qualification of tutor is "+ qualification);
            System.out.println("The evaluation period is "+ evaluationPeriod);
            System.out.println("The terminated date is "+terminationDate);
            System.out.println("The salary for the Tutor is "+ Salary);
        }
    }
}