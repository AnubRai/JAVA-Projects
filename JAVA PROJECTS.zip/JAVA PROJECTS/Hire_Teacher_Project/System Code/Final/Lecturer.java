class Lecturer extends Teacher{
    private double Salary;
    private String startingFrom;
    private String academicBlockNumber;
    private int dailyWorkingHour;
    private double advanceSalary;
    private boolean joined;
    private boolean terminated;
    Lecturer(String Subject, String interviewerName, int classesPerday,double Salary,int dailyWorkingHour){
      super(Subject,interviewerName,classesPerday); 
      this.Salary = Salary; 
      this.dailyWorkingHour = dailyWorkingHour;
      startingFrom = ""; 
      academicBlockNumber = ""; 
      advanceSalary = 0; 
      joined = false; 
      terminated = false;
    }
    public double getSalary(){
        return this.Salary;
    }
    public String startingFrom(){
        return this.startingFrom;
    }
    public int getdailyWorkingHour(){
        return this.dailyWorkingHour;
    }
    public String academicBlockNumber(){
        return this.academicBlockNumber;
    }
    public double advanceSalry(){
        return this.advanceSalary;
    }
    public boolean joined(){
        return this.joined;
    }
    public boolean terminated(){
        return this.terminated;
    }
    public void setSalary(double Salary){
        this.Salary = Salary;
    }
    public void setdailyWorkingHour(int dailyWorkingHour){
        this.dailyWorkingHour = dailyWorkingHour;
    }
    public void AppointLecturer(String LecturerName, String startingFrom, double advanceSalary, String academicBlockNumber){
    if(this.joined == true){
        System.out.println("The Lecturer's name is "+ this.getteacherName());
        System.out.println("The Academic Block Number is " + this.academicBlockNumber());
    }
    else{
        setteacherName(LecturerName);
        this.startingFrom = startingFrom;
        this.academicBlockNumber = academicBlockNumber;
        this.advanceSalary = advanceSalary;
        this.joined = true;
        this.terminated = false;
    }
    }
    public void LectureTermination(){
    if( this.terminated == true){
        System.out.println("The Lecture has been Successfully Terminated ");
    }
    else{
        setteacherName("");
        startingFrom = "";
        advanceSalary = 0.0;
        joined = false;
        terminated = true;
    }
    }
    public void print(){
        System.out.println("The subject is "+ this.getSubject());
        System.out.println("The Lecturer's name is "+ this.getteacherName());
        System.out.println("The Salary of the Lecturer is "+ this.Salary);
    }
    public void display(){
        super.display();
        if (joined == true){
            System.out.println("The name of the Teacher is "+getteacherName()); 
            System.out.println("The Termination Status of the Lecturer is "+terminated);
            System.out.println("The Lecturer is starting from "+startingFrom);
            System.out.println("The Lecturer's Advance Salary is "+advanceSalary);
        }
    }
}