import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import java.awt.Font;
import java.awt.Color;
public class InformaticCollege implements ActionListener{
    private JFrame frame;
    private JPanel panel;
    private JLabel label, ltitle, ltitle1,
    lSub,lName,lFName,lLName,lClass,lWork,lSalary,lNo,lname,lBlock,lfname,llname,lAdvance,lStart,
    lTSub,lTName,lTFName,lTLName,lTClass,lTSalary,lTAppyBy,lTerD,lTNo,lTname2,lTfname2,lTlname2,lTQualify,lTAppD,lTerD1,lTEvaluation;
    
    
    
    private JTextField Subject,Name,name,Salaryy,no,Fname,Lname,Advance,start,//lno,
    TSubject,TFName,TLName,TSalarys,TAppBy,TerD,Tno,Tfname2,Tlname2,Qualify,AppD,Evaluation,TerD1;
    
    
    private JButton Lecturer, Tutors, Add,Add1,Appoint,Appoint1,Display,Display1,Clear,Clear1,Terminate;
    
    private JComboBox c,c2,c3,c4;
    
    ArrayList<Teacher> Teacherlist = new ArrayList <Teacher>();
    
    public void setMainForm(){
        
        ltitle = new JLabel("WELCOME TO");
        Font font = new Font("Ink Free", Font.BOLD,20);
        ltitle.setFont(font);
        ltitle.setForeground(Color.blue);
        ltitle.setBounds(180,60,180,25);
        ltitle1 = new JLabel("INFORMATIC COLLEGE");
        ltitle1.setFont(font);
        ltitle1.setForeground(Color.blue);
        ltitle1.setBounds(140,120,250,25);
        
        Lecturer = new JButton("Lecturer");
        Lecturer.setBounds(55,200,150,30);
        Lecturer.addActionListener(this);
        
        Tutors = new JButton("Tutor");
        Tutors.setBounds(280,200,150,30);
        Tutors.addActionListener(this);
        
        frame = new JFrame("FORM");
        panel = new JPanel();
        panel.setLayout(null);
        panel.add(ltitle);
        panel.add(ltitle1);
        panel.add( Lecturer);
        panel.add(Tutors);
        frame.add(panel);
        frame.setSize(490,350);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    
    public void Lecturer(){
        frame= new JFrame("Lecturer");
        
        lSub = new JLabel("Subject :");
        frame.add(lSub);
        lSub.setBounds(15,10,200,20);
        
        Subject = new JTextField();
        frame.add(Subject);
        Subject.setBounds(140,10,150,20);
        
        lName = new JLabel("Interviewer's Name :");
        frame.add(lName);
        lName.setBounds(15,50,200,20);
        
        lFName = new JLabel("First Name");
        lFName .setFont(new Font("Arial", Font.PLAIN,12));
        frame.add(lFName);
        lFName.setBounds(142,70,200,20);
        
        
        Name = new JTextField();
        frame.add(Name);
        Name.setBounds(140,50,150,20);
        
        lLName = new JLabel("Last Name");
        lLName .setFont(new Font("Arial", Font.PLAIN,12));
        frame.add(lLName);
        lLName.setBounds(312,70,200,20);
        
        name = new JTextField();
        frame.add(name);
        name.setBounds(310,50,150,20);
        
        lClass = new JLabel("Classes Per Day :");
        frame.add(lClass);
        lClass.setBounds(15,105,200,20);
        
        String Choice [] = {"1", "2", "3", "4","5"};
        c = new JComboBox(Choice);
        frame.add(c);
        c.setBounds(140,105,48,20);
        
        lWork = new JLabel("Daily Working Hour :");
        frame.add(lWork);
        lWork.setBounds(312,105,200,20);
        
        String Choice2 [] = {"2","3", "4", "5", "6","7"};
        c2 = new JComboBox(Choice2);
        frame.add(c2);
        c2.setBounds(440,105,48,20);
        
        lSalary = new JLabel("Salary :");
        frame.add(lSalary);
        lSalary.setBounds(15,145,200,20);
        
        Salaryy = new JTextField();
        frame.add(Salaryy);
        Salaryy.setBounds(140,145,150,20);
        
        Add = new JButton("ADD");
        Add.addActionListener(this);
        Add.setForeground(Color.blue);
        frame.add(Add);
        Add.setBounds(225,185,100,20);
        
       
        lNo = new JLabel("Teacher No :");
        frame.add(lNo);
        lNo.setBounds(15,225,200,20);
        
        no = new JTextField();
        frame.add(no);
        no.setBounds(140,225,150,20);
        
        lname = new JLabel("Teacher's Name :");
        frame.add(lname);
        lname.setBounds(15,265,200,20);
        
        Fname = new JTextField();
        frame.add(Fname);
        Fname.setBounds(140,265,150,20);
        
        Lname = new JTextField();
        frame.add(Lname);
        Lname.setBounds(310,265,150,20);
        
        lfname = new JLabel("First Name");
        lfname .setFont(new Font("Arial", Font.PLAIN,12));
        frame.add(lfname);
        lfname.setBounds(142,285,200,20);
        
        llname = new JLabel("Last Name");
        llname .setFont(new Font("Arial", Font.PLAIN,12));
        frame.add(llname);
        llname.setBounds(312,285,200,20);
        
        lBlock = new JLabel("Academic Block Number :");
        frame.add(lBlock);
        lBlock.setBounds(15,320,200,20);
        
        String Choice3 [] = {"B-1", "B-2", "B-3", "B-4","B-5"};
        c3 = new JComboBox(Choice3);
        frame.add(c3);
        c3.setBounds(170,320,52,20);
        
        lAdvance = new JLabel("Advance Salary :");
        frame.add(lAdvance);
        lAdvance.setBounds(15,360,200,20);
        
        Advance = new JTextField();
        frame.add(Advance);
        Advance.setBounds(140,360,150,20);
        
        lStart = new JLabel("Starting From :");
        frame.add(lStart);
        lStart.setBounds(15,400,200,20);
        
        start = new JTextField();
        frame.add(start);
        start.setBounds(140,400,150,20);
        
        Appoint = new JButton("APPOINT");
        Appoint.addActionListener(this);
        Appoint.setForeground(Color.blue);
        frame.add(Appoint);
        Appoint.setBounds(10,440,100,20);
        
        
        Terminate = new JButton("TERMINATE");
        Terminate.addActionListener(this);
        Terminate.setForeground(Color.red);
        frame.add(Terminate);
        Terminate.setBounds(130,440,120,20);
        
        
        Display = new JButton("DISPLAY");
        Display.addActionListener(this);
        Display.setForeground(Color.blue);
        frame.add(Display);
        Display.setBounds(300,480,100,20);
        
        
        Clear = new JButton("CLEAR");
        Clear.addActionListener(this);
        Clear.setForeground(Color.red);
        frame.add(Clear);
        Clear.setBounds(420,480,100,20);
        
       
        frame.setSize(550,590);
        frame.setLayout(null);
        frame.setVisible(true);
    }
        
    public void Tutor(){
        frame= new JFrame("Tutor");
        
        lTSub = new JLabel("Subject :");
        frame.add(lTSub);
        lTSub.setBounds(15,3,110,40);
        
        TSubject = new JTextField();
        frame.add(TSubject);
        TSubject.setBounds(140,10,150,20);
        
        lTName = new JLabel("Interviewer's Name :");
        frame.add(lTName);
        lTName.setBounds(15,50,200,20);
        
        lTFName = new JLabel("First Name");
        lTFName .setFont(new Font("Arial", Font.PLAIN,12));
        frame.add(lTFName);
        lTFName.setBounds(142,70,200,20);
        
        lTLName = new JLabel("Last Name");
        lTLName .setFont(new Font("Arial", Font.PLAIN,12));
        frame.add(lTLName);
        lTLName.setBounds(312,70,200,20);
        
        TFName = new JTextField();
        frame.add(TFName);
        TFName.setBounds(140,50,150,20);
        
        TLName = new JTextField();
        frame.add(TLName);
        TLName.setBounds(310,50,150,20);
        
        lTClass = new JLabel("Classes Per Day :");
        frame.add(lTClass);
        lTClass.setBounds(15,105,200,20);
        
        String Choice [] = {"1", "2", "3", "4","5"};
        c4 = new JComboBox(Choice);
        frame.add(c4);
        c4.setBounds(140,105,48,20);
        
        lTSalary = new JLabel("Salary :");
        frame.add(lTSalary);
        lTSalary.setBounds(15,145,200,20);
        
        TSalarys = new JTextField();
        frame.add(TSalarys);
        TSalarys.setBounds(140,145,150,20);

        lTAppyBy = new JLabel("Appointed By :");
        frame.add(lTAppyBy);
        lTAppyBy.setBounds(15,190,200,20);
        
        TAppBy = new JTextField();
        frame.add(TAppBy);
        TAppBy.setBounds(140,190,150,20);

        lTerD = new JLabel("Termination Date :");
        frame.add(lTerD);
        lTerD.setBounds(15,235,200,20);
        
        TerD = new JTextField();
        frame.add(TerD);
        TerD.setBounds(140,235,150,20);
        
        Add1 = new JButton("ADD");
        Add1.addActionListener(this);
        Add1.setForeground(Color.blue);
        frame.add(Add1);
        Add1.setBounds(225,280,100,20);
        
        
        lTNo = new JLabel("Teacher No :");
        frame.add(lTNo);
        lTNo.setBounds(15,325,200,20);
        
        Tno = new JTextField();
        frame.add(Tno);
        Tno.setBounds(140,325,150,20);
        
        lTname2 = new JLabel("Teacher's Name :");
        frame.add(lTname2);
        lTname2.setBounds(15,370,200,20);
        
        Tfname2 = new JTextField();
        frame.add(Tfname2);
        Tfname2.setBounds(140,370,150,20);
        
        Tlname2 = new JTextField();
        frame.add(Tlname2);
        Tlname2.setBounds(310,370,150,20);
        
        lTfname2 = new JLabel("First Name");
        lTfname2.setFont(new Font("Arial", Font.PLAIN,12));
        frame.add(lTfname2);
        lTfname2.setBounds(142,390,200,20);
        
        JLabel lTlname2 = new JLabel("Last Name");
        lTlname2 .setFont(new Font("Arial", Font.PLAIN,12));
        frame.add(lTlname2);
        lTlname2.setBounds(312,390,200,20);
        
        lTQualify = new JLabel("Qualification :");
        frame.add(lTQualify);
        lTQualify.setBounds(15,435,200,20);
        
        Qualify = new JTextField();
        frame.add(Qualify);
        Qualify.setBounds(140,435,150,20);
        
        lTAppD = new JLabel("Appointed Date :");
        frame.add(lTAppD);
        lTAppD.setBounds(15,480,200,20);
        
        AppD = new JTextField();
        frame.add(AppD);
        AppD.setBounds(140,480,150,20);
        
        lTEvaluation = new JLabel("Evaluation Period :");
        frame.add(lTEvaluation);
        lTEvaluation.setBounds(15,525,200,20);
        
        Evaluation = new JTextField();
        frame.add(Evaluation);
        Evaluation.setBounds(140,525,150,20);
        
        lTerD1 = new JLabel("Termination Date :");
        frame.add(lTerD1);
        lTerD1.setBounds(15,570,200,20);
        
        TerD1 = new JTextField();
        frame.add(TerD1);
        TerD1.setBounds(140,570,150,20);
        
        Appoint1 = new JButton("APPOINT");
        Appoint1.addActionListener(this);
        Appoint1.setForeground(Color.blue);
        frame.add(Appoint1);
        Appoint1.setBounds(10,615,100,20);
        
        Display1 = new JButton("DISPLAY");
        Display1.addActionListener(this);
        Display1.setForeground(Color.blue);
        frame.add(Display1);
        Display1.setBounds(330,660,100,20);
        
        Clear1 = new JButton("CLEAR");
        Clear1.addActionListener(this);
        Clear1.setForeground(Color.red);
        frame.add(Clear1);
        Clear1.setBounds(470,660,100,20);
        
        frame.setSize(640,725);
        frame.setLayout(null);
        frame.setVisible(true);
    }
    
    public static void main(String[]args){
        InformaticCollege m= new InformaticCollege();
        m.setMainForm();
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getActionCommand().equals("Lecturer")){
            JOptionPane.showMessageDialog(null," Welcome to LECTURER FORM section ");
            Lecturer();
        }
        if(e.getActionCommand().equals("Tutor")){
            JOptionPane.showMessageDialog(null," Welcome to TUTOR FORM section ");
            Tutor();
        }
        
        if(e.getSource()==Clear){
            Subject.setText("");
            Name.setText("");
            name.setText("");
            Salaryy.setText("");
            c.setSelectedIndex(0);
            c2.setSelectedIndex(0);
            no.setText("");
            Fname.setText("");
            Lname.setText("");
            Advance.setText("");
            start.setText("");
            c3.setSelectedIndex(0);
        }
        
        if(e.getSource()==Clear1){
            TSubject.setText("");
            TFName.setText("");
            TLName.setText("");
            c4.setSelectedIndex(0);
            TSalarys.setText("");
            TAppBy.setText("");
            TerD.setText("");
            
            Tno.setText("");
            Tfname2.setText("");
            Tlname2.setText("");
            Qualify.setText("");
            AppD.setText("");
            Evaluation.setText("");
            TerD1.setText("");
        }
        
        if (e.getSource()==Add){
            addlecturer();
        }
        
        if(e.getSource()==Add1){
            addtutor();
        }
        
        if(e.getSource()==Display){
            displaylecturer();
        }
        
        if(e.getSource()==Display1){
            displaytutor();
        }
        
        if(e.getSource()==Appoint){
            appointlecturer();
        }
        
        if(e.getSource()==Appoint1){
            appointtutor();
        }
        
        if(e.getSource()==Terminate){
            terminatelecturer();
        } 
        
    }
    public void addlecturer(){
        try{
            String asubject = Subject.getText();
            String interviewerName= Name.getText();
            String interviewerLName= name.getText();
            String classesPerDay = (String)c.getSelectedItem();
            String salary = Salaryy.getText();
            String dailyWorkingHours = (String)c2.getSelectedItem();
            String interViewerName = interviewerName+""+interviewerLName;
            if(asubject.equals("")||interviewerName.equals("")||classesPerDay.equals("")||salary.equals("")||dailyWorkingHours.equals("")){
                JOptionPane.showMessageDialog(frame, " Please do not leave the fileds EMPTY ","Error",JOptionPane.ERROR_MESSAGE);
            }
            else{
                int convertedclassesPerDay = Integer.parseInt(classesPerDay);
                float convertedsalary =Float.parseFloat(salary);
                int converteddailyWorkingHours =Integer.parseInt(dailyWorkingHours);
                
                Lecturer l1 =new Lecturer(asubject, interViewerName, convertedclassesPerDay, convertedsalary, converteddailyWorkingHours);
                Teacherlist.add(l1);
                
                JOptionPane.showMessageDialog(frame, "The provided information has been successfully added.","Success",JOptionPane.INFORMATION_MESSAGE);
            }
        }
        catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(frame, " Please provide the correct Information ","Error",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void addtutor(){
        try{
            String Tsubject = TSubject.getText();
            String TinterviewerName1= TFName.getText();
            String TinterViewerName2= TLName.getText();
            String TclassesPerDay = (String)c4.getSelectedItem();
            String TSalary = TSalarys.getText();
            String TAppointedBy = TAppBy.getText();
            String TTerminationDate = TerD.getText();
            String TInterViewerName= TinterviewerName1+" "+TinterViewerName2;
            if(Tsubject.equals("") || TInterViewerName.equals("")|| TclassesPerDay.equals("") || TSalary.equals("") || TAppointedBy.equals("")){
                 JOptionPane.showMessageDialog(frame, " Please do not leave the fileds EMPTY ","Error",JOptionPane.ERROR_MESSAGE);
            }
            else{
                int convertClassesPerDay = Integer.parseInt(TclassesPerDay);
                float convertSalary =Float.parseFloat(TSalary);
                
                Tutor t1 =new Tutor (Tsubject, TInterViewerName, convertClassesPerDay, convertSalary, TAppointedBy, TTerminationDate);
                
                Teacherlist.add(t1);
                
                JOptionPane.showMessageDialog(frame,"The provided information has been successfully added ","Success",JOptionPane.INFORMATION_MESSAGE);
            }
        }
        catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(frame, " Please provide the correct Information ","Error",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void displaylecturer(){
        for(Teacher l1 : Teacherlist){
            if(l1 instanceof Lecturer){
                Lecturer lecturer = (Lecturer) l1;
                lecturer.display();
            }
        } 
    }
    
    public void displaytutor(){
        for(Teacher T1 : Teacherlist){
            if(T1 instanceof Tutor){
                Tutor tutor=(Tutor) T1;
                tutor.display();
            }
        }
    }
    public void appointlecturer(){
         try{
            String number = no.getText();
            String fname= Fname.getText();
            String lname= Lname.getText();
            String advancesalary = Advance.getText();
            String startingfrom = start.getText();
            String academicblocknumber = (String)c3.getSelectedItem();
            String teacherName=fname+""+lname;
            if(number.equals("") || teacherName.equals("") || advancesalary.equals("") || startingfrom.equals("") || academicblocknumber.equals(""))
            {
                JOptionPane.showMessageDialog(frame, " Please do not leave the fileds EMPTY ","Error",JOptionPane.ERROR_MESSAGE);
            }
            else{
                int convertedteacherno = Integer.parseInt(number);
                double convertedadvancesalary =Double.parseDouble(advancesalary);
                if(convertedteacherno >= 0 && convertedteacherno < Teacherlist.size()){
                    if(Teacherlist.get(convertedteacherno) instanceof Lecturer){
                        Lecturer l1 = (Lecturer)Teacherlist.get(convertedteacherno );
                        if (l1.joined() == false){
                            l1.AppointLecturer(teacherName,startingfrom,convertedadvancesalary,academicblocknumber );
                            JOptionPane.showMessageDialog(frame, " The Lecturer has been appointed Sucessfully ","Success",JOptionPane.INFORMATION_MESSAGE);
                        }
                        else{
                            JOptionPane.showMessageDialog(frame, " The Lecturer has already been Appointed ","Success",JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                    else{
                        JOptionPane.showMessageDialog(frame, " Invalid Entry ","Error",JOptionPane.ERROR_MESSAGE);  
                    }
                }
            }
        }
        
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(frame, " Please provide the correct Information ","Error",JOptionPane.ERROR_MESSAGE);
        }
    }
    public void appointtutor(){
        try{
            String Tnumber = Tno.getText();
            String Tfname = Tfname2.getText();
            String Tlname = Tlname2.getText();
            String qualification = Qualify.getText();
            String appointedDate = AppD.getText();
            String terminatedDate = TerD1.getText();
            String evaluate = Evaluation.getText();
            String TteacherName = Tfname2 +" "+ Tlname2;
            if(Tnumber.equals("") ||  TteacherName.equals("") || qualification.equals("") || appointedDate.equals("") || terminatedDate.equals("")){
                JOptionPane.showMessageDialog(frame, " Please do not leave the fileds EMPTY ","Error",JOptionPane.ERROR_MESSAGE);
            }
            else{
                int convertno = Integer.parseInt(Tnumber);
                if(convertno >= 0 &&  convertno < Teacherlist.size()){
                    if(Teacherlist.get(convertno) instanceof Tutor){
                        Tutor t1 = (Tutor)Teacherlist.get(convertno);
                        if (t1.getjoined() == false){
                            t1.AppointTutor(TteacherName, appointedDate, terminatedDate,evaluate, qualification);
                            JOptionPane.showMessageDialog(frame, " The Tutor has been appointed Sucessfully ","Sucess",JOptionPane.INFORMATION_MESSAGE);
                        }
                        else{
                            JOptionPane.showMessageDialog(frame, " The Tutor is alraedy Appointed ","Sucess",JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                }
            }
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(frame, " Please provide the correct Information ","Error",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void terminatelecturer(){
        try{
             String number = no.getText();
             if(number.equals("")){
                 JOptionPane.showMessageDialog(frame, " Please do not leave the fileds EMPTY ","Error",JOptionPane.ERROR_MESSAGE);
             }
             else{
                 int convertedlecnumber = Integer.parseInt(number);
                 if( convertedlecnumber>= 0 && convertedlecnumber < Teacherlist.size()){
                      if(Teacherlist.get(convertedlecnumber) instanceof Lecturer){
                          Lecturer l1 = (Lecturer)Teacherlist.get(convertedlecnumber);
                          if (l1.joined() == true){
                              l1.LectureTermination();
                              JOptionPane.showMessageDialog(frame, " The Lecturer has been terminated sucessfully ","Sucess",JOptionPane.INFORMATION_MESSAGE);
                          }
                          else{
                              JOptionPane.showMessageDialog(frame, " The Lecturer is already terminated ","Sucess",JOptionPane.INFORMATION_MESSAGE);
                          }
                      }
                      else{
                          JOptionPane.showMessageDialog(frame, " Not an object of Lecturer ","Error",JOptionPane.ERROR_MESSAGE);  
                      }
                 }
                 else{
                     JOptionPane.showMessageDialog(frame, "Invalid!!!","Error",JOptionPane.ERROR_MESSAGE);
            
                 }
             }
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(frame, " Please provide the correct Information for Termination ","Error",JOptionPane.ERROR_MESSAGE);
        }
    } 
}        