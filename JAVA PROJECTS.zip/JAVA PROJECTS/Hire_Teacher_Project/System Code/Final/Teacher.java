public class Teacher{
    private String Subject;
    private String teacherName;
    private String interviewerName;
    private int classesPerday;
    Teacher(String Subject,String interviewerName,int classesPerday){
        this.Subject = Subject; 
        this.interviewerName = interviewerName;
        this.classesPerday = classesPerday;
        teacherName = "";
    }
    public String getSubject(){
         return this.Subject;
    }
    public String getinterviewerName(){
        return this.interviewerName;
    }
    public int getclassesPerday(){
        return this.classesPerday;
    }
    public String getteacherName(){
        return this.teacherName;
    }
    public void setteacherName(String teacherName){
        this.teacherName=teacherName;
    }
    public void display(){
        System.out.println("The name of the interviewer is "+interviewerName);
        System.out.println("The Subject is "+Subject);
        System.out.println("Classes per day is "+classesPerday);
    }
}